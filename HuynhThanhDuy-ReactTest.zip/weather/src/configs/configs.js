// Should proxy this
// Your API KEY here
export const API_KEY = "56ef69743f830a99d5cfd4cb641abc89";
export const WEATHER_API_ENDPOINT = "https://api.openweathermap.org";

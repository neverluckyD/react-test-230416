import React from "react";

function Nav() {
  return (
    <h2 className="is-size-4 has-text-weight-bold section-title mt-2">Today's Weather</h2>
  );
}

export default Nav;
